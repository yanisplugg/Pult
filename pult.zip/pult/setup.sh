#!/bin/bash

echo "Выберите вашу операционную систему:"
echo "1) RedOS"
echo "2) Ubuntu / Debian / Linux Mint"
echo "3) ALT Linux"
read -p "Введите номер (1-3): " choice

case "$choice" in
    1)
        echo "Вы выбрали RedOS"
        unzip pultr.zip -d pultr_dir
        cd pultr_dir/pult
        chmod +x run.sh
        ./run.sh
        ;;
    2)
        echo "Вы выбрали Ubuntu/Debian"
        unzip pultu.zip -d pultu_dir
        cd pultu_dir/pult
        chmod +x run.sh
        ./run.sh
        ;;
    3)
        echo "Вы выбрали ALT Linux"
        unzip pultz.zip -d pultz_dir
        cd pultz_dir/pult
        chmod +x run.sh
        ./run.sh
        ;;
    *)
        echo "Неверный выбор. Завершение установки."
        exit 1
        ;;
esac
